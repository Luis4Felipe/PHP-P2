<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Inserção de Bebidas</title>
</head>
<body>
    <h1>Formulário de Exclusão de Bebidas</h1>
    <form action="<?php echo e(route('bebidas.update',$bebida->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <label for="nome">Informe o nome do bebida</label>
        <input type="text" name="nome" id="nome" value="<?php echo e($bebida->id); ?>" disabled><br>
        <label for="marca">Informe o marca do bebida</label>
        <input type="text" name="marca" id="marca" value="<?php echo e($bebida->marca); ?>" disabled><br>
        <label for="preco">Informe o preco do bebida</label>
        <input type="number" name="preco" id="preco" value="<?php echo e($bebida->preco); ?>" disabled></br>
        <button type="submit">Salvar</button>
    </form>
</body>
</html><?php /**PATH C:\Users\aluno\Downloads\projeto-crud-25052024\projeto-crud\resources\views/bebida/delete.blade.php ENDPATH**/ ?>