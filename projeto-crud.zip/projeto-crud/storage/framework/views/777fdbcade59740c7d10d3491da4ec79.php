<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bebidas</title>
</head>
<body>
    <h1>Bebidas</h1>
    <a href="<?php echo e(route('bebidas.create')); ?>">INSERIR BEBIDA</a>
    <table>
        <tr>
            <td>Nome</td>
            <td></td>
        </tr>
        <?php $__currentLoopData = $bebidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($c->nome); ?></td>
            <td><a href="<?php echo e(route('bebidas.edit',$c->id)); ?>">Alterar</a></td>
            <td><a href="/bebidas/delete/<?php echo e($c->id); ?>">Excluir</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\Users\aluno\Downloads\projeto-crud-25052024\projeto-crud\resources\views/bebida/index.blade.php ENDPATH**/ ?>