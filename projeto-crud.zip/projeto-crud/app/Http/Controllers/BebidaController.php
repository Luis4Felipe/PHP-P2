<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bebiba;

class BebidaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $bebidas = Bebiba::all();
        return view("bebida.index",compact('bebidas'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //Mostrar formulário de cadastro do bebida
        //Método Get
        return view('bebida.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        Bebiba::create([
            'nome' => $request->input('nome'),
            'marca' => $request->input('marca'),
            'preco' => $request->input('preco')
        ]);
        dd(Bebiba::all()->toArray());
}

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $bebida = Bebiba::findOrFail($id);
        return view("bebida.edit",compact('bebida'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        $bebida = Bebiba::findOrFail($id);
        $bebida->update([
            'nome' => $request->input('nome'),
            'marca' => $request->input('marca'),
            'email' => $request->input('email')
        ]);
        return 'Registro alterado com sucesso!';
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        $bebida = Bebiba::findOrFail($id);
        $bebida->delete();
        return "Registro excluído com sucesso!";
    }

    public function delete(string $id) {
        //Método Get
        //Mostrar o formulário com os dados antes de excluir

        $bebida = Bebiba::findOrFail($id);
        return view("bebida.delete",compact('bebida'));
    }
}
