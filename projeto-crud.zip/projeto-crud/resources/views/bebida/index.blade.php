<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bebidas</title>
</head>
<body>
    <h1>Bebidas</h1>
    <a href="{{route('bebidas.create')}}">INSERIR BEBIDA</a>
    <table>
        <tr>
            <td>Nome</td>
            <td></td>
        </tr>
        @foreach ($bebidas as $c)
        <tr>
            <td>{{$c->nome}}</td>
            <td><a href="{{ route('bebidas.edit',$c->id)}}">Alterar</a></td>
            <td><a href="/bebidas/delete/{{$c->id}}">Excluir</a></td>
        </tr>
        @endforeach
    </table>
</body>
</html>