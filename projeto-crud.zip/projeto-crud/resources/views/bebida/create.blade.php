<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Inserção de Bebidas</title>
</head>
<body>
    <h1>Formulário de Inserção de Bebidas</h1>
    <form action="{{ route('bebidas.store')}}" method="POST">
        @CSRF
        <label for="nome">Informe o nome da Bebida</label>
        <input type="text" name="nome" id="nome"><br>
        <label for="marca">Inofrme o marca da Bebida</label>
        <input type="text" name="marca" id="marca"><br>
        <label for="preco">Informe o preco da Bebida</label>
        <input type="number" name="preco" id="preco"></br>
        <button type="submit">Salvar</button>
    </form>
</body>
</html>