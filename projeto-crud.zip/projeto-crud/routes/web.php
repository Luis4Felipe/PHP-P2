<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MensagemController;
use App\Http\Controllers\BebidaController;

Route::get('/', function () {
    return view('welcome');
});

Route::get("/mensagem/{mensagem}", [MensagemController::class, 'mostrarMensagem']);

Route::resources([
    'bebidas' => BebidaController::class,
    #produtos => ProdutosController::class
]);

Route::get('/bebidas/delete/{id}', [BebidaController::class,'delete']);