@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Excluir Bebida</h1>
    <p>Tem certeza que deseja excluir a bebida {{ $bebida->nome }}?</p>
    <form action="{{ route('bebida.destroy', $bebida->id) }}" method="POST">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-danger">Excluir</button>
        <a href="{{ route('bebida.index') }}" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
@endsection
