@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Lista de Bebidas</h1>
    <a href="{{ route('bebida.create') }}" class="btn btn-primary">Adicionar Bebida</a>
    <table class="table">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Tipo</th>
                <th>Marca</th>
                <th>Preço</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            @foreach($bebidas as $bebida)
                <tr>
                    <td>{{ $bebida->nome }}</td>
                    <td>{{ $bebida->tipo }}</td>
                    <td>{{ $bebida->marca }}</td>
                    <td>{{ $bebida->preco }}</td>
                    <td>
                        <a href="{{ route('bebida.edit', $bebida->id) }}" class="btn btn-warning">Editar</a>
                        <form action="{{ route('bebida.destroy', $bebida->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Excluir</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
