<?php

// app/Http/Controllers/BebidaController.php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bebida;

class BebidaController extends Controller
{
    public function index()
    {
        $bebidas = Bebida::all();
        return view('bebida.index', compact('bebidas'));
    }

    public function create()
    {
        return view('bebida.create');
    }

    public function store(Request $request)
    {
        Bebida::create($request->all());
        return redirect()->route('bebida.index')->with('success', 'Bebida criada com sucesso!');
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $bebida = Bebida::findOrFail($id);
        return view('bebida.edit', compact('bebida'));
    }

    public function update(Request $request, $id)
    {
        $bebida = Bebida::findOrFail($id);
        $bebida->update($request->all());
        return redirect()->route('bebida.index')->with('success', 'Bebida atualizada com sucesso!');
    }

    public function destroy($id)
    {
        $bebida = Bebida::findOrFail($id);
        $bebida->delete();
        return redirect()->route('bebida.index')->with('success', 'Bebida excluída com sucesso!');
    }

    public function delete($id)
    {
        $bebida = Bebida::findOrFail($id);
        return view('bebida.delete', compact('bebida'));
    }
}

