

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Lista de Pizzas</h1>
    <a href="<?php echo e(route('pizza.create')); ?>" class="btn btn-primary">Adicionar Pizza</a>
    <table class="table">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Ingredientes</th>
                <th>Tamanho</th>
                <th>Preço</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pizza->nome); ?></td>
                    <td><?php echo e($pizza->ingredientes); ?></td>
                    <td><?php echo e($pizza->tamanho); ?></td>
                    <td><?php echo e($pizza->preco); ?></td>
                    <td>
                        <a href="<?php echo e(route('pizza.edit', $pizza->id)); ?>" class="btn btn-warning">Editar</a>
                        <form action="<?php echo e(route('pizza.destroy', $pizza->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projeto-laravel-bebidas\bebidas\resources\views/pizza/index.blade.php ENDPATH**/ ?>