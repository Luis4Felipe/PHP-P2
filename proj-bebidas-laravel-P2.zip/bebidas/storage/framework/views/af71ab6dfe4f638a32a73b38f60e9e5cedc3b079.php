

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Lista de Bebidas</h1>
    <a href="<?php echo e(route('bebida.create')); ?>" class="btn btn-primary">Adicionar Bebida</a>
    <table class="table">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Tipo</th>
                <th>Marca</th>
                <th>Preço</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bebidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bebida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($bebida->nome); ?></td>
                    <td><?php echo e($bebida->tipo); ?></td>
                    <td><?php echo e($bebida->marca); ?></td>
                    <td><?php echo e($bebida->preco); ?></td>
                    <td>
                        <a href="<?php echo e(route('bebida.edit', $bebida->id)); ?>" class="btn btn-warning">Editar</a>
                        <form action="<?php echo e(route('bebida.destroy', $bebida->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projeto-laravel-bebidas\bebidas\resources\views/bebida/index.blade.php ENDPATH**/ ?>